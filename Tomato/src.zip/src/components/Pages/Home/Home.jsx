import React from 'react'
import './Home.css'

const Home = () => {
  return (
    <div>
      
    </div>
  )
}

export default Home
