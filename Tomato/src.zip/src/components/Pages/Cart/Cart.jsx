import React from 'react'
import  './Cart.css'

const cart = () => {
  return (
    <div>
      
    </div>
  )
}

export default cart
